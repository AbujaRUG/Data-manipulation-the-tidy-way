library(tidyverse)
# library(dplyr)
### Selection features 
# - :, !, & and |, c()  

data_tbl2_long %>% 
  select(Country,`ISO Code`,Region,Position,Year)

data_tbl2_long %>% 
  select(1:3,12:13)

data_tbl2_long %>% 
  select(Country,`ISO Code`,Region,Position,Year)

data_tbl2_wide %>% 
  select(-Year_2020, -Year_2019) %>% View()

data_tbl2_wide %>% 
  select(!c(Year_2020, Year_2019)) %>% View()

# wrong
# data_tbl2_wide %>% 
#   select(!Year_2020, !Year_2019) %>% View()


### Helpers functions
# - everything(),last_col(),starts_with(),ends_with(),contains(),matches(),
# all_of(), any_of(), where(), num_range()

data_tbl2_wide %>% 
  select(everything()) %>% View()


data_tbl2_wide %>% 
  select(last_col()) %>% View()

data_tbl2_wide %>% 
  # select the last column before the last 5 columns
  select(last_col(5)) %>% View()

data_tbl2_wide %>% 
  # select the first to the column before the last 5 columns
  select(1:last_col(5)) %>% View()


data_tbl1 %>% 
  # column name starts with sum
  select(starts_with("sum")) %>% View()
data_tbl1 %>% 
  # column name starts with sum
  select(starts_with("summer")) %>% View()

data_tbl1 %>% 
  # columns name starts with summer or winter
  select(starts_with(c("summer", "winter"))) %>% View()

data_tbl1 %>% 
  # columns name ends with total
  select(ends_with("total")) %>% View()

data_tbl1 %>% 
  select(starts_with(c("summer", "winter")) & !ends_with("total")) %>% 
  View()

data_tbl1 %>% 
  # columns name contains "in" i.e. countries, winter_
  # what is the output?
  select(contains("in")) %>% View()

data_tbl1 %>% 
  # columns name contains "ter" 
  # what is the output?
  select(contains("ter")) %>% View()

data_tbl1 %>% 
  # columns name contains "u" i.e. countries, winter_
  # what is the output?
  select(contains("u")) %>% View()


# interpreted as a regular expression
data_tbl1 %>% select(matches("ter|tot")) %>% View()

billboard %>% select(num_range("wk", 10:15))

data_tbl1 %>% select(where(is.numeric)) %>% View()


## mutate()
# Newly created variables are available immediately
data_tbl1_long %>%
  mutate(
    total_medals = rowSums(data_tbl1_long[,c(5:7)])
  )

# As well as adding new variables, you can use mutate() to
# remove variables and modify existing variables.
data_tbl1_long %>%
  mutate(
    participations = NULL,
    # rowSums(.)
    total_medals = rowSums(data_tbl1_long[,c(5:7)])
  )

# Use across() with mutate() to apply a transformation
# to multiple columns in a tibble.
data_tbl1_long %>%
  select(1:3) %>%
  mutate(across(where(is.character), as.factor))

# By default, new columns are placed on the far right.
# override with `.before` or `.after`
data_tbl1_long %>%
  mutate(
    participations = NULL,
    total_medals = rowSums(data_tbl1_long[,c(5:7)]),
    # rowSums(.)
    pct_gold_medals = replace_na((gold/total_medals)*100, 0), .before = 1
  )

# wrong
data_tbl1_long %>%
  mutate(
    participations = NULL,
    total_medals = rowSums(data_tbl1_long[,c(5:7)]), .after = -1,
    # rowSums(.)
    pct_gold_medals = replace_na((gold/total_medals)*100, 0), .before = 1
  )

# correct
data_tbl1_long %>%
  mutate(
    participations = NULL,
    total_medals = rowSums(data_tbl1_long[,c(5:7)]), .after = -1) %>% 
    # rowSums(.)
  mutate(pct_gold_medals = replace_na((gold/total_medals)*100, 0), .before = 1
  ) %>% View()


# filter()

# Filtering by one criterion
filter(data_tbl1_long, season == "winter")
filter(data_tbl1_long, gold > 20)

# Filtering by multiple criteria within a single logical expression
filter(data_tbl1_long, season == "winter" & gold > 20)
filter(data_tbl1_long, season == "winter" | gold > 20)

# When multiple expressions are used, they are combined using &
filter(data_tbl1_long, season == "winter", gold > 20)


# The filtering operation may yield different results on grouped
# tibbles because the expressions are computed within groups.
#
# The following filters rows where `gold` is greater than the
# global average:
data_tbl1_long %>% filter(gold > mean(gold, na.rm = TRUE))

# Whereas this keeps rows with `mass` greater than the gender
# average:
data_tbl1_long %>% group_by(season) %>% filter(gold > mean(gold, na.rm = TRUE))


# summarise()
### Useful functions

# Center: mean(), median()
data_tbl1_long %>%
  group_by(season) %>%
  summarise(avg_no_gold = mean(gold), 
            avg_no_silver = mean(silver), 
            avg_no_bronze = mean(bronze))


# data_tbl1_long %>%
#   group_by(season,countries) %>%
#   summarise(avg_no_gold = sum(gold), 
#             avg_no_silver = sum(silver), 
#             avg_no_bronze = sum(bronze))


# arrange()
data_tbl1_long %>%
  mutate(
    participations = NULL,
    total_medals = rowSums(data_tbl1_long[,c(5:7)]), .after = -1) %>% 
  arrange(desc(total_medals))












